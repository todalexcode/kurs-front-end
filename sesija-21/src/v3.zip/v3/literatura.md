# Za citanje

* https://www.w3.org/Style/CSS/
* https://developer.mozilla.org/en-US/docs/Learn/CSS/Introduction_to_CSS
* https://material.io/
* https://www.w3schools.com/cssref/css3_pr_mediaquery.asp

# Alati

* https://caniuse.com/
* https://projects.lukehaas.me/css-loaders/
* http://www.colorzilla.com/gradient-editor/

# Fontovi i ikone
* https://fonts.google.com
* https://fontawesome.com/
* https://useiconic.com/open/
* http://glyph.smarticons.co/
* https://material.io/icons/