console.log("Hello, world!");
// console.log(2+8);
// console.log(2+2*2);
// console.log("2" + 2);
